import os
import csv

# 🔧 VERİ OKUMA FONKSİYONU
def read_input(file_path):
    with open(file_path, 'r') as f:
        all_numbers = list(map(float, f.read().split()))

    depot_count = int(all_numbers[0])
    customer_count = int(all_numbers[1])
    idx = 2

    depot_caps = []
    depot_costs = []
    for _ in range(depot_count):
        depot_caps.append(all_numbers[idx])
        depot_costs.append(all_numbers[idx + 1])
        idx += 2

    demands = []
    for _ in range(customer_count):
        demands.append(all_numbers[idx])
        idx += 1

    trans_costs = []
    for _ in range(customer_count):
        row = all_numbers[idx:idx + depot_count]
        if len(row) != depot_count:
            raise ValueError("❌ Taşıma maliyetleri eksik!")
        trans_costs.append(row)
        idx += depot_count

    return depot_count, customer_count, depot_caps, depot_costs, demands, trans_costs

# 🤖 GREEDY ATAMA ALGORİTMASI
def greedy_assignment(depot_count, customer_count, depot_caps, depot_costs, demands, trans_costs):
    remaining_caps = depot_caps.copy()
    used_depots = [False] * depot_count
    total_cost = 0
    assignments = [-1] * customer_count

    for cust in range(customer_count):
        demand = demands[cust]
        sorted_depots = sorted(range(depot_count), key=lambda d: trans_costs[cust][d])

        for depot in sorted_depots:
            if remaining_caps[depot] >= demand:
                assignments[cust] = depot
                remaining_caps[depot] -= demand
                total_cost += trans_costs[cust][depot]

                if not used_depots[depot]:
                    used_depots[depot] = True
                    total_cost += depot_costs[depot]
                break

    return total_cost, assignments

# 📤 SONUÇLARI CSV DOSYASINA KAYDET
def write_to_csv(filename, results):
    with open(filename, mode='w', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(["Boyut", "Toplam Maliyet", "Müşteri Atamaları"])
        for result in results:
            boyut, maliyet, atamalar = result
            writer.writerow([boyut, round(maliyet, 2), ' '.join(map(str, atamalar))])

# 🧠 ANA PROGRAM
if __name__ == "__main__":
    files = ["wl_25.txt", "wl_50.txt", "wl_200.txt", "wl_300.txt", "wl_500.txt"]
    base_path = "C:/Users/guler/OneDrive/Masaüstü/wsp ödev/"
    results = []

    for file in files:
        file_path = os.path.join(base_path, file)
        print(f"\n📂 İşleniyor: {file}")
        if os.path.exists(file_path):
            try:
                d_count, c_count, caps, costs, demands, trans = read_input(file_path)
                total_cost, assignment = greedy_assignment(d_count, c_count, caps, costs, demands, trans)
                print(f"✅ {file} - Toplam Maliyet: {round(total_cost, 2)}")
                results.append((c_count, total_cost, assignment))
            except Exception as e:
                print(f"❌ {file} işlenemedi: {e}")
        else:
            print(f"❌ {file} bulunamadı!")

    # CSV dosyasına yaz
    write_to_csv("C:/Users/guler/OneDrive/Masaüstü/wsp ödev/wlp_sonuclar.csv", results)
    print("\n📊 Sonuçlar 'wlp_sonuclar.csv' dosyasına yazıldı.")
