import os
import random
import time
import matplotlib.pyplot as plt
from openpyxl import Workbook

# ---------------- VERİ ÜRET ----------------
def veri_uret():
    print("📦 Yüksek verimli veri setleri oluşturuluyor...")

    def dosya_olustur(path, n, kapasite):
        with open(path, "w") as f:
            f.write(f"{n} {kapasite}\n")
            for _ in range(n):
                deger = random.randint(200, 400)     # yüksek değerli
                agirlik = random.randint(1, 20)      # düşük ağırlıklı
                f.write(f"{deger} {agirlik}\n")

    data_dir = os.path.join(os.path.dirname(__file__), "data")
    os.makedirs(data_dir, exist_ok=True)

    veri_setleri = [
        ("40.txt", 40, 500),
        ("300.txt", 300, 4000),
        ("1000.txt", 1000, 15000),
        ("10000.txt", 10000, 100000),
    ]

    for dosya, n, kapasite in veri_setleri:
        yol = os.path.join(data_dir, dosya)
        dosya_olustur(yol, n, kapasite)
        print(f"✅ {dosya} oluşturuldu.")

    return data_dir

# ---------------- VERİ OKU ----------------
def veri_yukle(dosya_yolu):
    with open(dosya_yolu, "r") as f:
        satirlar = f.readlines()
    n, kapasite = map(int, satirlar[0].split())
    degerler = []
    agirliklar = []
    for satir in satirlar[1:]:
        v, w = map(int, satir.split())
        degerler.append(v)
        agirliklar.append(w)
    return n, kapasite, degerler, agirliklar

# ---------------- ALGORİTMA ----------------
def knapsack(degerler, agirliklar, kapasite):
    n = len(degerler)
    dp = [[0] * (kapasite + 1) for _ in range(n + 1)]
    for i in range(1, n + 1):
        for w in range(kapasite + 1):
            if agirliklar[i-1] <= w:
                dp[i][w] = max(dp[i-1][w],
                               dp[i-1][w - agirliklar[i-1]] + degerler[i-1])
            else:
                dp[i][w] = dp[i-1][w]
    secilenler = [0] * n
    w = kapasite
    for i in range(n, 0, -1):
        if dp[i][w] != dp[i-1][w]:
            secilenler[i-1] = 1
            w -= agirliklar[i-1]
    return dp[n][kapasite], secilenler

# ---------------- ZAMAN ANALİZİ ----------------
def zaman_analizi(data_dir, dosyalar):
    print("\n📊 Zaman analizi başlıyor...")
    boyutlar = []
    sureler = []
    for dosya in dosyalar:
        yol = os.path.join(data_dir, dosya)
        n, kapasite, d, a = veri_yukle(yol)
        basla = time.time()
        _, _ = knapsack(d, a, kapasite)
        bitir = time.time()
        boyutlar.append(n)
        sureler.append(bitir - basla)
        print(f"{dosya} süresi: {bitir - basla:.4f} sn")

    plt.plot(boyutlar, sureler, marker='o')
    plt.xlabel("Dosya Boyutu (item sayısı)")
    plt.ylabel("Çalışma Süresi (saniye)")
    plt.title("Knapsack Zaman Analizi")
    plt.grid(True)
    plt.tight_layout()
    plt.savefig(os.path.join(data_dir, "zaman_analizi.png"))
    plt.show()

# ---------------- EXCEL ----------------
def excel_yaz(data_dir, dosyalar):
    print("\n📥 Excel dosyası yazılıyor...")
    wb = Workbook()
    ws = wb.active
    ws.title = "Sonuçlar"
    ws.append(["Dosya Boyut", "Optimal Value Değeri", "Optimal çözüm (0,1 dizisi)", "Optimal çözüme dahil edilen itemler"])

    for dosya in dosyalar:
        yol = os.path.join(data_dir, dosya)
        n, kapasite, d, a = veri_yukle(yol)
        val, secilen = knapsack(d, a, kapasite)
        secilen_index = [str(i) for i, v in enumerate(secilen) if v == 1]
        ws.append([
            dosya.replace(".txt", ""),
            val,
            ",".join(map(str, secilen)),
            ",".join(secilen_index)
        ])

    wb.save("sonuc_excel.xlsx")
    print("✅ sonuc_excel.xlsx kaydedildi.")

# ---------------- ANA FONKSİYON ----------------
def main():
    dosyalar = ["40.txt", "300.txt", "1000.txt", "10000.txt"]
    data_dir = veri_uret()
    zaman_analizi(data_dir, dosyalar)
    excel_yaz(data_dir, dosyalar)

if __name__ == "__main__":
    main()
